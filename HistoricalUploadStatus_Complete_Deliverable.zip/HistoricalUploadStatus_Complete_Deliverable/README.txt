HISTORICAL UPLOAD STATUS - FRONTEND DELIVERABLE
================================================
Everything in this zip mirrors the exact folder structure of your
StreamingEngine WEB project (view/, controller/, fragment/, model/,
i18n/, manifest.json at the root). Copy each file to the SAME path
in your real project, or apply the find/replace merge instructions
given separately in chat if you'd rather not overwrite whole files.

BRAND-NEW FILES (create these - nothing to merge)
--------------------------------------------------
view/HistoricalUploadStatus.view.xml
controller/HistoricalUploadStatus.controller.js
fragment/RequestDetailsPanel.fragment.xml
fragment/RequestCommentDialog.fragment.xml

  -> New "Historical Data Upload Status" screen (page title/route
     unchanged - only the Launchpad TILE name changed, see below):
     filter bar (Plant / Data Source / Status / Flow Type + Go), a
     request list table, and a collapsible right-hand detail panel
     with Approve / Reject / On Hold actions and a mandatory-comment
     dialog for Reject/On Hold.
  -> Currently backed by a local mock dataset (8 rows matching your
     mock-up) - the request list and the 3 action buttons are wired
     with clearly marked "// TODO backend integration" comments and
     the exact Illuminator QueryTemplate call shape to use once the
     Z_HIST_UPLOAD_REQ-backed queries/transactions exist.
  -> The third action is "On Hold" (matching the original spec
     wording), not "Defer" - button id button-hold-request, handler
     fnHoldRequest, i18n keys historicalUploadStatusOnHold /
     historicalUploadStatusOnHoldSuccess / historicalUploadStatusOnHoldStatus.
     Status code is "OH" throughout, consistent with the spec.
  -> Flow Type filter now includes an "All" option (reuses the
     existing commonAll i18n key). fnLoadFlowType unshifts an
     {DS_DESCRIPTION: commonAll, ID_FLOW_TYPE: "%"} entry and
     defaults the combobox selection to it; onSearch's flow-type
     filter condition now treats "%" as a wildcard matching every
     row - same pattern already used by the Plant dropdown.

MODIFIED EXISTING FILES (overwrite your current copy, or diff first)
----------------------------------------------------------------------
view/Launchpad.view.xml
  -> Adds one new GenericTile right after the "Archive Flows" tile
     inside the panel-admin section. Its displayed name is
     "Historical Data Upload Request" (i18n key
     launchPadHistoricalUploadRequest) - NOTE this is deliberately
     different from the screen's own title/breadcrumb, which still
     says "Historical Data Upload Status" (historicalUploadStatusTitle)
     - only the tile's name on the Launchpad ends in "Request" per
     your instruction, the page you land on after clicking it still
     says "Status".

controller/Launchpad.controller.js
  -> Adds onClickHistoricalUploadStatus (navigation) and a mock tile
     counter (fnLoadHistoricalUploadStatusCountMock), kept separate
     from the real fnLoadKPIS backend call.

model/formatter.js
  -> Adds statusIconUploadRequest / statusColorUploadRequest /
     statusStateUploadRequest (icon+color for Pending/Approved/
     Rejected/Cancelled/On Hold/Expired), same pattern as the
     existing statusIconTagCatalog.

manifest.json
  -> Adds the "HistoricalUploadStatus" route + target (route name and
     pattern unchanged - only the Launchpad tile's display text
     changed, not the route/navigation id).

i18n/i18n.properties
  -> Adds a new "#Historical Upload Status" section at the end.
  -> ALSO CHANGES SIX EXISTING VALUES (search for these keys, don't
     just append - the whole file is included so a diff will show
     exactly what moved):
       contextualFlowHistoricalDataUploadEnable  -> "Request Historical Upload"
       contextualFlowHistoricalDataUploadCancel  -> "Cancel Upload Request"
       contextualFlowHistoricalDataUploadEnableDetails -> reworded
       contextualFlowCancelUploadMsg             -> reworded
       tagCatalogEnableDataLoad                  -> "Request Historical Upload"
       tagCatalogDisableDataLoad                 -> "Cancel Upload Request"
  -> The full copy-pasteable bundle of both the edited keys and the
     new appended section was also given directly in chat as of this
     round, as the single source of truth if this README and the
     live file ever drift.

controller/ContextualFlows.controller.js
controller/ExternalFlows.controller.js
  -> The "Historical Upload"/"Cancel Historical Upload" buttons (now
     relabeled via the i18n keys above) no longer call the live
     upload-start/stop transaction directly. Submit now calls a new
     fnRequestHistoricalDataUpload() (mock confirmation); Cancel now
     calls a new fnCancelUploadRequest() (mock confirmation). The
     original fnEnableHistoricalDataUploadSubmit function is left
     intact/untouched, just no longer called from these two buttons -
     it's the real execution logic your backend will likely still
     need once "Approve" is wired to actually trigger the upload.

controller/TagCatalog.controller.js
  -> SAME treatment, applied to a DIFFERENT feature: Tag Catalog's
     "Enable Data Load"/"Disable Data Load" buttons (tag-scoped
     Initial Load, backed by StreamingEngine/InitialLoad/Query/
     InitialLoadXacuteQuery - a separate module from the flow-scoped
     Historical Upload above, but functionally the same class of
     risk to MEX DF, per your confirmation this is in scope). Submit
     now calls the same fnRequestHistoricalDataUpload() pattern;
     Disable/Cancel now calls fnCancelUploadRequest(). The original
     fnEnableInitialDataLoadSubmit is left intact/untouched for the
     same reason as fnEnableHistoricalDataUploadSubmit above.
     NOTE: no matching view.xml change was needed here, since the
     button labels are driven entirely by the i18n keys listed above
     (tagCatalogEnableDataLoad/tagCatalogDisableDataLoad) - same as
     how contextualFlowHistoricalDataUploadEnable/Cancel drive BOTH
     ContextualFlows.view.xml and ExternalFlows.view.xml already.

THINGS TO CONFIRM / ADJUST BEFORE/AFTER MERGING
--------------------------------------------------
1. controller/HistoricalUploadStatus.controller.js, ~line 58:
     var sPlantCoRole = "STREAMING_ENGINE_PLANTCO";
   This role name is a GUESS following your existing
   STREAMING_ENGINE_ADMIN/STREAMING_ENGINE_USER convention. Replace
   it with whatever your actual PlantCo authorization role is called.

2. Tile placement: the new tile was added to panel-admin (to match
   your mock-up's visual grouping). Your real Launchpad's Jobs/Queue/
   PCo Monitoring tiles live in a separate panel-monitoring section -
   move the tile there instead if you'd prefer it grouped with those.

3. Tile name vs. page title now intentionally differ ("...Request" on
   the tile, "...Status" on the page/breadcrumb/route) - flag if you
   actually want the page title changed to match too; that wasn't
   part of this instruction so it was left as-is.

4. Nothing here talks to a real backend yet. Every action (viewing
   the request list, Approve/Reject/On Hold, Request/Cancel Upload
   from any of the three trigger points - ContextualFlows,
   ExternalFlows, TagCatalog) is either mock data or a client-side-
   only confirmation. Each spot that needs backend wiring is marked
   "// TODO backend integration" with the exact param shape expected.
   Note the TagCatalog request is keyed by a TAG LIST, while the
   ContextualFlows/ExternalFlows requests are keyed by a single FLOW
   ID + date range - your Z_HIST_UPLOAD_REQ data model / request-list
   screen will need to represent both shapes.

5. Only the Flow Type dropdown got an explicit "All" option this
   round, per your instruction - Data Source and Status dropdowns
   still rely on "no selection = show everything" (MultiComboBox
   default) rather than an explicit "All" chip. Say if you want the
   same explicit-"All" treatment applied to those two as well.

6. Double check whether there are any OTHER bulk-backfill triggers
   elsewhere in the app beyond these three (ContextualFlows,
   ExternalFlows, TagCatalog) that should also be brought under this
   same governance gate - these three were found by searching for
   every reference to "HistoricalDataUpload"/"EnableDataLoad" in the
   codebase, but a targeted search is only as good as the terms used.
