HISTORICAL UPLOAD STATUS - FRONTEND DELIVERABLE
================================================
Everything in this zip mirrors the exact folder structure of your
StreamingEngine WEB project (view/, controller/, fragment/, model/,
i18n/, manifest.json at the root). Copy each file to the SAME path
in your real project.

BRAND-NEW FILES (create these - nothing to merge)
--------------------------------------------------
view/HistoricalUploadStatus.view.xml
controller/HistoricalUploadStatus.controller.js
fragment/RequestDetailsPanel.fragment.xml
fragment/RequestCommentDialog.fragment.xml

  -> New "Historical Data Upload Status" screen: filter bar (Plant /
     Data Source / Status / Flow Type + Go), a request list table,
     and a collapsible right-hand detail panel with Approve / Reject
     / Defer actions and a mandatory-comment dialog for Reject/Defer.
  -> Currently backed by a local mock dataset (8 rows matching your
     mock-up) - the request list and the 3 action buttons are wired
     with clearly marked "// TODO backend integration" comments and
     the exact Illuminator QueryTemplate call shape to use once the
     Z_HIST_UPLOAD_REQ-backed queries/transactions exist.

MODIFIED EXISTING FILES (overwrite your current copy, or diff first)
----------------------------------------------------------------------
view/Launchpad.view.xml
  -> Adds one new GenericTile ("Historical Data Upload Status") right
     after the "Archive Flows" tile inside the panel-admin section.

controller/Launchpad.controller.js
  -> Adds onClickHistoricalUploadStatus (navigation) and a mock tile
     counter (fnLoadHistoricalUploadStatusCountMock), kept separate
     from the real fnLoadKPIS backend call.

model/formatter.js
  -> Adds statusIconUploadRequest / statusColorUploadRequest /
     statusStateUploadRequest (icon+color for Pending/Approved/
     Rejected/Cancelled/Deferred/Expired), same pattern as the
     existing statusIconTagCatalog.

manifest.json
  -> Adds the "HistoricalUploadStatus" route + target.

i18n/i18n.properties
  -> Adds a new "#Historical Upload Status" section at the end.
  -> ALSO CHANGES TWO EXISTING VALUES (search for these keys, don't
     just append - the whole file is included so a diff will show
     exactly what moved):
       contextualFlowHistoricalDataUploadEnable  -> "Request Historical Upload"
       contextualFlowHistoricalDataUploadCancel  -> "Cancel Upload Request"
       contextualFlowHistoricalDataUploadEnableDetails -> reworded
       contextualFlowCancelUploadMsg             -> reworded

controller/ContextualFlows.controller.js
controller/ExternalFlows.controller.js
  -> The "Historical Upload"/"Cancel Historical Upload" buttons (now
     relabeled via the i18n keys above) no longer call the live
     upload-start/stop transaction directly. Submit now calls a new
     fnRequestHistoricalDataUpload() (mock confirmation); Cancel now
     calls a new fnCancelUploadRequest() (mock confirmation). The
     original fnEnableHistoricalDataUploadSubmit function is left
     intact/untouched, just no longer called from these two buttons -
     it's the real execution logic your backend will likely still
     need once "Approve" is wired to actually trigger the upload.

THINGS TO CONFIRM / ADJUST BEFORE/AFTER MERGING
--------------------------------------------------
1. controller/HistoricalUploadStatus.controller.js, ~line 58:
     var sPlantCoRole = "STREAMING_ENGINE_PLANTCO";
   This role name is a GUESS following your existing
   STREAMING_ENGINE_ADMIN/STREAMING_ENGINE_USER convention. Replace
   it with whatever your actual PlantCo authorization role is called.

2. Tile placement: the new tile was added to panel-admin (to match
   your mock-up's visual grouping). Your real Launchpad's Jobs/Queue/
   PCo Monitoring tiles live in a separate panel-monitoring section -
   move the tile there instead if you'd prefer it grouped with those.

3. Nothing here talks to a real backend yet. Every action (viewing
   the request list, Approve/Reject/Defer, Request/Cancel Upload)
   is either mock data or a client-side-only confirmation. Each spot
   that needs backend wiring is marked "// TODO backend integration"
   with the exact param shape expected.
