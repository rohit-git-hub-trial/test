HISTORICAL UPLOAD STATUS - FRONTEND DELIVERABLE
================================================
Everything in this zip mirrors the exact folder structure of your
StreamingEngine WEB project (view/, controller/, fragment/, model/,
i18n/, manifest.json at the root). Copy each file to the SAME path
in your real project, or apply the find/replace merge instructions
given separately in chat if you'd rather not overwrite whole files.

BRAND-NEW FILES (create these - nothing to merge)
--------------------------------------------------
view/HistoricalUploadStatus.view.xml
controller/HistoricalUploadStatus.controller.js
fragment/RequestDetailsPanel.fragment.xml
fragment/RequestCommentDialog.fragment.xml

  -> New "Historical Data Upload Status" screen: filter bar (Plant /
     Data Source / Status / Flow Type + Go), a request list table,
     and a collapsible right-hand detail panel with Approve / Reject
     / On Hold actions and a mandatory-comment dialog for Reject/On
     Hold.
  -> Currently backed by a local mock dataset (8 rows matching your
     mock-up) - the request list and the 3 action buttons are wired
     with clearly marked "// TODO backend integration" comments and
     the exact Illuminator QueryTemplate call shape to use once the
     Z_HIST_UPLOAD_REQ-backed queries/transactions exist.
  -> NOTE: the third action is "On Hold" (matching the original spec
     wording), not "Defer" - button id button-hold-request, handler
     fnHoldRequest, i18n keys historicalUploadStatusOnHold /
     historicalUploadStatusOnHoldSuccess / historicalUploadStatusOnHoldStatus.
     Status code is "OH" throughout, consistent with the spec.

MODIFIED EXISTING FILES (overwrite your current copy, or diff first)
----------------------------------------------------------------------
view/Launchpad.view.xml
  -> Adds one new GenericTile ("Historical Data Upload Status") right
     after the "Archive Flows" tile inside the panel-admin section.

controller/Launchpad.controller.js
  -> Adds onClickHistoricalUploadStatus (navigation) and a mock tile
     counter (fnLoadHistoricalUploadStatusCountMock), kept separate
     from the real fnLoadKPIS backend call.

model/formatter.js
  -> Adds statusIconUploadRequest / statusColorUploadRequest /
     statusStateUploadRequest (icon+color for Pending/Approved/
     Rejected/Cancelled/On Hold/Expired), same pattern as the
     existing statusIconTagCatalog.

manifest.json
  -> Adds the "HistoricalUploadStatus" route + target.

i18n/i18n.properties
  -> Adds a new "#Historical Upload Status" section at the end.
  -> ALSO CHANGES SIX EXISTING VALUES (search for these keys, don't
     just append - the whole file is included so a diff will show
     exactly what moved):
       contextualFlowHistoricalDataUploadEnable  -> "Request Historical Upload"
       contextualFlowHistoricalDataUploadCancel  -> "Cancel Upload Request"
       contextualFlowHistoricalDataUploadEnableDetails -> reworded
       contextualFlowCancelUploadMsg             -> reworded
       tagCatalogEnableDataLoad                  -> "Request Historical Upload"
       tagCatalogDisableDataLoad                 -> "Cancel Upload Request"

controller/ContextualFlows.controller.js
controller/ExternalFlows.controller.js
  -> The "Historical Upload"/"Cancel Historical Upload" buttons (now
     relabeled via the i18n keys above) no longer call the live
     upload-start/stop transaction directly. Submit now calls a new
     fnRequestHistoricalDataUpload() (mock confirmation); Cancel now
     calls a new fnCancelUploadRequest() (mock confirmation). The
     original fnEnableHistoricalDataUploadSubmit function is left
     intact/untouched, just no longer called from these two buttons -
     it's the real execution logic your backend will likely still
     need once "Approve" is wired to actually trigger the upload.

controller/TagCatalog.controller.js
  -> SAME treatment, applied to a DIFFERENT feature: Tag Catalog's
     "Enable Data Load"/"Disable Data Load" buttons (tag-scoped
     Initial Load, backed by StreamingEngine/InitialLoad/Query/
     InitialLoadXacuteQuery - a separate module from the flow-scoped
     Historical Upload above, but functionally the same class of
     risk to MEX DF, per your confirmation this is in scope). Submit
     now calls the same fnRequestHistoricalDataUpload() pattern;
     Disable/Cancel now calls fnCancelUploadRequest(). The original
     fnEnableInitialDataLoadSubmit is left intact/untouched for the
     same reason as fnEnableHistoricalDataUploadSubmit above.
     NOTE: no matching view.xml change was needed here, since the
     button labels are driven entirely by the i18n keys listed above
     (tagCatalogEnableDataLoad/tagCatalogDisableDataLoad) - same as
     how contextualFlowHistoricalDataUploadEnable/Cancel drive BOTH
     ContextualFlows.view.xml and ExternalFlows.view.xml already.

THINGS TO CONFIRM / ADJUST BEFORE/AFTER MERGING
--------------------------------------------------
1. controller/HistoricalUploadStatus.controller.js, ~line 58:
     var sPlantCoRole = "STREAMING_ENGINE_PLANTCO";
   This role name is a GUESS following your existing
   STREAMING_ENGINE_ADMIN/STREAMING_ENGINE_USER convention. Replace
   it with whatever your actual PlantCo authorization role is called.

2. Tile placement: the new tile was added to panel-admin (to match
   your mock-up's visual grouping). Your real Launchpad's Jobs/Queue/
   PCo Monitoring tiles live in a separate panel-monitoring section -
   move the tile there instead if you'd prefer it grouped with those.

3. Nothing here talks to a real backend yet. Every action (viewing
   the request list, Approve/Reject/On Hold, Request/Cancel Upload
   from any of the three trigger points - ContextualFlows,
   ExternalFlows, TagCatalog) is either mock data or a client-side-
   only confirmation. Each spot that needs backend wiring is marked
   "// TODO backend integration" with the exact param shape expected.
   Note the TagCatalog request is keyed by a TAG LIST, while the
   ContextualFlows/ExternalFlows requests are keyed by a single FLOW
   ID + date range - your Z_HIST_UPLOAD_REQ data model / request-list
   screen will need to represent both shapes.

4. Double check whether there are any OTHER bulk-backfill triggers
   elsewhere in the app beyond these three (ContextualFlows,
   ExternalFlows, TagCatalog) that should also be brought under this
   same governance gate - these three were found by searching for
   every reference to "HistoricalDataUpload"/"EnableDataLoad" in the
   codebase, but a targeted search is only as good as the terms used.
